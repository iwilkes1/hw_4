#!/bin/bash

make run -C src ARGS="$* 1"
