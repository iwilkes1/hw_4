#!/bin/bash
javadoc -sourcepath ./src -subpackages edu -d ./doc
make -C src
